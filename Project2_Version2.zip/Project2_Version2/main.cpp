/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: taraf
 *
 * Created on July 26, 2024, 11:40 AM
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime>
#include <vector>
#include <algorithm> // For sorting and searching

using namespace std;

// Named constants
#define BLACKJACK 21
#define DEALER_STAND 17

// Struct to hold card information
struct Card {
    int rank;
    char suit;
};

// Function prototypes
void initializeGame(int &money);
int getBetAmount(int money);
void dealInitialCards(vector<Card> &playerCards, vector<Card> &dealerCards);
void displayCards(const vector<Card> &cards, const string &owner);
int calculateTotal(const vector<Card> &cards);
void playerTurn(vector<Card> &playerCards, int &playerTotal);
void dealerTurn(vector<Card> &dealerCards, int &dealerTotal);
void displayFinalResults(int playerTotal, int dealerTotal, int &money, int betAmount);
void recordGameResults(ofstream &outFile, int gameCount, int playerTotal, int dealerTotal, int money);
void sortAndSearchPlayers();
string getCardString(const Card &card);

int main() {
    srand(static_cast<unsigned int>(time(0)));
    char again;
    int money, betAmount;
    ofstream outFile("game_results.txt");
    int gameCount = 0;
    cout << "Welcome to the Blackjack game!" << endl;
    initializeGame(money);
    do {
        betAmount = getBetAmount(money);
        vector<Card> playerCards;
        vector<Card> dealerCards;
        dealInitialCards(playerCards, dealerCards);
        int playerTotal = calculateTotal(playerCards);
        int dealerTotal = calculateTotal(dealerCards);
        playerTurn(playerCards, playerTotal);
        if (playerTotal <= BLACKJACK) {
            dealerTurn(dealerCards, dealerTotal);
        }
        displayFinalResults(playerTotal, dealerTotal, money, betAmount);
        recordGameResults(outFile, gameCount, playerTotal, dealerTotal, money);
        cout << "Player's total money: $" << money << endl;
        if (money < 10) {
            cout << "You don't have enough money to continue playing. Game over!" << endl;
            break;
        }
        cout << "Do you want to keep playing? (y/n): ";
        cin >> again;
        gameCount++;
    } while (again == 'y' && money >= 10);
    cout << "Total games played: " << gameCount << endl;
    outFile.close();
    sortAndSearchPlayers();
    return 0;
}

void initializeGame(int &money) {
    do {
        cout << "How much money do you want to have at the start of the game? (min 1, max 200): ";
        cin >> money;
        if (money > 200) {
            cout << "Overflow error: Starting money cannot be greater than 200. Starting Price is $200" << endl;
            money = 200;
        }
    } while (money < 1);
}

int getBetAmount(int money) {
    int betAmount;
    do {
        cout << "How much do you want to bet this round? (min 10, max 200): ";
        cin >> betAmount;
    } while (betAmount < 10 || betAmount > 200);
    return betAmount;
}

void dealInitialCards(vector<Card> &playerCards, vector<Card> &dealerCards) {
    for (int i = 0; i < 2; i++) {
        playerCards.push_back({rand() % 13 + 1, "DHSC"[rand() % 4]});
        dealerCards.push_back({rand() % 13 + 1, "DHSC"[rand() % 4]});
    }
}

string getCardString(const Card &card) {
    string cardStr;
    switch (card.rank) {
        case 1:
            cardStr = "Ace";
            break;
        case 11:
            cardStr = "Jack";
            break;
        case 12:
            cardStr = "Queen";
            break;
        case 13:
            cardStr = "King";
            break;
        default:
            cardStr = to_string(card.rank);
    }
    cardStr += " of ";
    switch (card.suit) {
        case 'D':
            cardStr += "Diamonds";
            break;
        case 'H':
            cardStr += "Hearts";
            break;
        case 'S':
            cardStr += "Spades";
            break;
        case 'C':
            cardStr += "Clubs";
            break;
    }
    return cardStr;
}

void displayCards(const vector<Card> &cards, const string &owner) {
    cout << owner << " cards: ";
    for (const Card &card : cards) {
        cout << getCardString(card) << ", ";
    }
    cout << endl;
}

int calculateTotal(const vector<Card> &cards) {
    int total = 0;
    int aces = 0;
    for (const Card &card : cards) {
        if (card.rank == 1) {
            aces++;
            total += 11;
        } else if (card.rank > 10) {
            total += 10;
        } else {
            total += card.rank;
        }
    }
    while (total > BLACKJACK && aces > 0) {
        total -= 10;
        aces--;
    }
    return total;
}

void playerTurn(vector<Card> &playerCards, int &playerTotal) {
    char choice;
    do {
        displayCards(playerCards, "Player");
        cout << "Player total: " << playerTotal << ". Do you want to hit (h) or stand (s)? ";
        cin >> choice;
        if (choice == 'h') {
            playerCards.push_back({rand() % 13 + 1, "DHSC"[rand() % 4]});
            playerTotal = calculateTotal(playerCards);
            if (playerTotal > BLACKJACK) {
                cout << "Player busts with " << playerTotal << "!" << endl;
                break;
            }
        }
    } while (choice == 'h');
}

void dealerTurn(vector<Card> &dealerCards, int &dealerTotal) {
    while (dealerTotal < DEALER_STAND) {
        dealerCards.push_back({rand() % 13 + 1, "DHSC"[rand() % 4]});
        dealerTotal = calculateTotal(dealerCards);
    }
    displayCards(dealerCards, "Dealer");
    cout << "Dealer's total is " << dealerTotal << endl;
}

void displayFinalResults(int playerTotal, int dealerTotal, int &money, int betAmount) {
    cout << "Player final total: " << playerTotal << endl;
    cout << "Dealer final total: " << dealerTotal << endl;
    if (playerTotal > BLACKJACK) {
        cout << "Dealer wins!" << endl;
        money -= betAmount;
    } else if (dealerTotal > BLACKJACK || playerTotal > dealerTotal) {
        cout << "Player wins!" << endl;
        money += betAmount;
    } else if (playerTotal < dealerTotal) {
        cout << "Dealer wins!" << endl;
        money -= betAmount;
    } else {
        cout << "It's a tie!" << endl;
    }
}

void recordGameResults(ofstream &outFile, int gameCount, int playerTotal, int dealerTotal, int money) {
    outFile << "Game " << gameCount + 1 << ": " << endl;
    outFile << "Player total: " << playerTotal << endl;
    outFile << "Dealer total: " << dealerTotal << endl;
    outFile << "Player's total money: $" << money << endl;
    outFile << "------------------------" << endl;
}

void sortAndSearchPlayers() {
    vector<string> players = {"Alice", "Bob", "Charlie", "David"};
    sort(players.begin(), players.end());
    cout << "Sorted players: ";
    for (const string &player : players) {
        cout << player << " ";
    }
    cout << endl;
    string searchName;
    cout << "Enter player name to search: ";
    cin >> searchName;
    if (binary_search(players.begin(), players.end(), searchName)) {
        cout << searchName << " found in the list." << endl;
    } else {
        cout << searchName << " not found in the list." << endl;
    }
}



