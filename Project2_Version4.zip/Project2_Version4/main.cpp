/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: taraf
 *
 * Created on July 28, 2024, 11:36 AM
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime>
#include <vector>
#include <algorithm>

//System Libraries
using namespace std;

//User Libraries

//Function Prototypes
void initGm(float &money); // Initialize the game with starting money
int getBet(float money, int minBet = 10, int maxBet = 200); // Get the bet amount for the current round
void dealCards(vector<int> &plyrCds, vector<int> &dealCds, vector<string> &plyrNms, vector<string> &dealNms); // Deal initial cards to player and dealer
string cardStr(int card, int suit); // Convert a card number and suit to a string representation
void dspPlyrCds(const vector<string> &cards); // Display the player's cards
int calcTot(const vector<int> &cards); // Calculate the total value of the cards
void plyrTrn(vector<int> &plyrCds, vector<string> &plyrNms, int &plyrTot); // Player's turn to hit or stand
void dealTrn(vector<int> &dealCds, vector<string> &dealNms, int &dealTot, int dealStnd); // Dealer's turn to hit or stand
void dspResults(int plyrTot, int dealTot, float &money, int betAmt, int &winnings); // Display the final results of the game
void recResults(ofstream &outFile, int gmCnt, int plyrTot, int dealTot, float money); // Record the game results in a file
void dsp1DArr(const int winnings[], int size); // Function prototype for displaying 1D array
void readFile(ifstream &inFile); // Read and display player scores from a file
void dspStats(int totGms, int plyrWns, int dealWns, int ties); // Display game statistics at the end
void bblSort(vector<int> &scores); // Bubble sort to sort scores
void slctSort(vector<int> &scores); // Selection sort to sort scores
void dspScores(const vector<int> &scores); // Display the sorted scores
bool srchScr(const vector<int> &scores, int score); // Search for a specific score in the sorted list
bool srchCrd(const vector<string> &cardNms, const string &card); // Overloaded function to search for a specific card in the player's hand
void dsp2DArr(const int scores[][2], int rnds);  void dsp1DArr(const int winnings[], int size); // Function prototype for displaying  1 and 2D array

//Execution Begins Here
int main(int argc, char** argv) {
    //Seed the random number generator
    srand(static_cast<unsigned int>(time(0))); // Seed the random number generator

    //Declare Variables
    char again; // Variable to check if player wants to play again
    float money; // Variable for player's money
    int betAmt; // Variable for bet amount
    ofstream outFile("game_results.txt"); if (!outFile) { cout << "Error opening file to write results!" << endl; exit(1);} // Exit if file cannot be opened
    ifstream inFile("game_scores.txt"); // File to read player scores
    int gmCnt = 0; // Count of games played
    int plyrWns = 0; // Count of player wins
    int dealWns = 0; // Count of dealer wins
    int ties = 0; // Count of ties
    const int maxRnd = 10; // Maximum number of rounds
    vector<int> plyrScrs; // Vector to store player scores
    int scores[maxRnd][2] = {};  int winnings[maxRnd] = {};  // 2D array to store player and dealer scores and 1d to store player winnings

    //Welcome message
    cout << "Welcome to the Blackjack game!" << endl; // Welcome message

    //Initialize Variables
    initGm(money); // Initialize the game with starting money

    //Map Inputs to Outputs -> Process
    //Main game loop
    do {
        const int blackjack = 21; // Constant for blackjack value
        const int dealStnd = 17; // Constant for dealer stand value

        betAmt = getBet(money); // Get the bet amount for the current round

        // Vectors to store the cards and card names of the player and dealer
        vector<int> plyrCds;
        vector<int> dealCds;
        vector<string> plyrNms;
        vector<string> dealNms;

        dealCards(plyrCds, dealCds, plyrNms, dealNms); // Deal initial cards to player and dealer

        int plyrTot = calcTot(plyrCds); // Calculate the total value of player's cards
        int dealTot = calcTot(dealCds); // Calculate the total value of dealer's cards

        plyrTrn(plyrCds, plyrNms, plyrTot); // Player's turn to hit or stand

        if (plyrTot <= blackjack) { // If player does not bust, dealer takes their turn
            dealTrn(dealCds, dealNms, dealTot, dealStnd);
        }
        int roundWinnings = 0;
        dspResults(plyrTot, dealTot, money, betAmt, roundWinnings); // Display the final results of the game
        winnings[gmCnt] = roundWinnings;
        recResults(outFile, gmCnt, plyrTot, dealTot, money); // Record the game results in a file

        // Update win counts based on game results
        if (plyrTot > blackjack || (dealTot <= blackjack && dealTot > plyrTot)) {
            dealWns++;
        } else if (dealTot > blackjack || plyrTot > dealTot) {
            plyrWns++;
        } else {
            ties++;
        }

        plyrScrs.push_back(plyrTot); // Add player score to the list

        if (gmCnt < maxRnd) { // Store the scores in the 2D array
            scores[gmCnt][0] = plyrTot;
            scores[gmCnt][1] = dealTot;
        }

        cout << "Player's total money: $" << fixed << setprecision(2) << money << endl; // Display the player's total money

        if (money < 10) { // Check if the player has enough money to continue playing
            cout << "You don't have enough money to continue playing. Game over!" << endl; outFile.close(); inFile.close(); exit(0);
             // End the game if the player doesn't have enough money
        }

        cout << "Do you want to keep playing? (y/n): "; // Ask the player if they want to keep playing
        cin >> again;

        gmCnt++; // Increment the number of games played

    } while (again == 'y' && money >= 10 && gmCnt < maxRnd); // Repeat loop if player wants to play again and has enough money

    //Display Inputs/Outputs
    cout << "Total games played: " << abs(gmCnt) << endl; // Display the total number of games played
    dsp2DArr(scores, gmCnt);  dsp1DArr(winnings, gmCnt); // Display all scores using the 2D array and winnings with 1d array

    //Exit the Program - Cleanup
    outFile.close(); // Close the output file
    readFile(inFile); // Read and display player scores from a file
    dspStats(gmCnt, plyrWns, dealWns, ties); // Display game statistics
    slctSort(plyrScrs); // Sort and display player scores using selection sort
    dspScores(plyrScrs);

    int srchFor = 21; // Search for a specific score in the sorted list
    if (srchScr(plyrScrs, srchFor)) {
        cout << "Score " << abs(srchFor) << " found in the list." << endl;
    } else {
        cout << "Score " << abs(srchFor) << " not found in the list." << endl;
    }

    return 0;
}

// Initialize the game with the starting money
void initGm(float &money) {
    static int initCls = 0; // Static variable to count the number of times the function is called
    initCls++;
    cout << "Initializing game for the " << abs(initCls) << " time(s)." << endl;

    do {
        cout << "How much money do you want to have at the start of the game? (min 11, max 200): ";
        cin >> money;
        if (money > 200) {
            cout << "Overflow error: Starting money cannot be greater than 200. Starting Price is $200" << endl;
            money = 200;
        }
    } while (money <= 10);
}

// Get the bet amount for the current round with a default minimum bet amount
int getBet(float money, int minBet, int maxBet) { 
    int betAmt;
    do {
        cout << "How much do you want to bet this round? (min " << abs(minBet) << ", max " << abs(maxBet) << "): ";
        cin >> betAmt;
    } while (betAmt < minBet || betAmt > maxBet);
    return betAmt;
}

// Deal the initial cards to the player and dealer
void dealCards(vector<int> &plyrCds, vector<int> &dealCds, vector<string> &plyrNms, vector<string> &dealNms) {
    for (int i = 0; i < 2; i++) {
        int card = rand() % 13 + 1;
        int suit = rand() % 4;
        plyrCds.push_back(card);
        plyrNms.push_back(cardStr(card, suit));
        
        card = rand() % 13 + 1;
        suit = rand() % 4;
        dealCds.push_back(card);
        dealNms.push_back(cardStr(card, suit));
    }
}

// Convert a card number and suit to a string representation
string cardStr(int card, int suit) {
    string crdStr;
    switch (card) {
        case 1: crdStr = "Ace"; break;
        case 11: crdStr = "Jack"; break;
        case 12: crdStr = "Queen"; break;
        case 13: crdStr = "King"; break;
        default: crdStr = to_string(card);
    }
    crdStr += " of ";
    switch (suit) {
        case 0: crdStr += "Clubs"; break;
        case 1: crdStr += "Diamonds"; break;
        case 2: crdStr += "Hearts"; break;
        case 3: crdStr += "Spades"; break;
    }
    return crdStr;
}

// Display the player's cards
void dspPlyrCds(const vector<string> &cards) {
    cout << "Player cards: ";
    for (const string &card : cards) {
        cout << card << " ";
    }
    cout << endl;
}

// Calculate the total value of the cards
int calcTot(const vector<int> &cards) {
    int total = 0;
    int aces = 0;
    for (int card : cards) {
        if (card == 1) {
            aces++;
            total += 11;
        } else if (card > 10) {
            total += 10;
        } else {
            total += card;
        }
    }
    while (total > 21 && aces > 0) {
        total -= 10;
        aces--;
    }
    return total;
}

// Player's turn to hit or stand
void plyrTrn(vector<int> &plyrCds, vector<string> &plyrNms, int &plyrTot) {
    char choice;
    do {
        dspPlyrCds(plyrNms); // Show player's cards
        cout << "Player total: " << abs(plyrTot) << ". Do you want to hit (h) or stand (s)? "; // Ask player if they want to hit or stand
        cin >> choice;
        if (choice == 'h') {
            int card = rand() % 13 + 1;
            int suit = rand() % 4;
            plyrCds.push_back(card); // Add new card to player's hand
            plyrNms.push_back(cardStr(card, suit)); // Convert card to string and add to player's card names
            plyrTot = calcTot(plyrCds); // Calculate new total of player's cards
            if (plyrTot > 21) {
                cout << "Player busts with " << abs(plyrTot) << "!" << endl; // Player busts if total is over 21
            }
        }
    } while (choice == 'h' && plyrTot <= 21);
}

// Dealer's turn to hit until they reach the stand limit
void dealTrn(vector<int> &dealCds, vector<string> &dealNms, int &dealTot, int dealStnd) {
    while (dealTot < dealStnd) {
        int card = rand() % 13 + 1;
        int suit = rand() % 4;
        dealCds.push_back(card); // Add new card to dealer's hand
        dealNms.push_back(cardStr(card, suit)); // Convert card to string and add to dealer's card names
        dealTot = calcTot(dealCds); // Calculate new total of dealer's cards
    }
    cout << "Dealer's total is " << abs(dealTot) << endl;
}

// Display the final results of the game
void dspResults(int plyrTot, int dealTot, float &money, int betAmt, int &winnings) {
    cout << "Player final total: " << abs(plyrTot) << endl;
    cout << "Dealer final total: " << abs(dealTot) << endl;

    if (plyrTot > 21) {
        cout << "Dealer wins!" << endl; winnings = -betAmt; // Update winnings for this round
        money -= betAmt; // Dealer wins, player loses bet amount 
    } else if (dealTot > 21 || plyrTot > dealTot) {
        cout << "Player wins!" << endl; winnings = betAmt; // Update winnings for this round
        money += betAmt; // Player wins, player gains bet amount
    } else if (plyrTot < dealTot) {
        cout << "Dealer wins!" << endl; winnings = -betAmt; // Update winnings for this round
        money -= betAmt; // Dealer wins, player loses bet amount
    } else {
        cout << "It's a tie!" << endl; winnings = 0; // No change in winnings for a tie and game is tie
    }
}

// Record the game results in a file
void recResults(ofstream &outFile, int gmCnt, int plyrTot, int dealTot, float money) {
    outFile << "Game " << gmCnt + 1 << ": " << endl;
    outFile << "Player total: " << abs(plyrTot) << endl;
    outFile << "Dealer total: " << abs(dealTot) << endl;
    outFile << "Player's total money: $" << fixed << setprecision(2) << abs(money) << endl;
    outFile << "------------------------" << endl;
}



    



// Read and display player scores from a file
void readFile(ifstream &inFile) {
    if (!inFile) {
        cout << "Error opening file!" << endl;
        return;
    }

    string line;
    while (getline(inFile, line)) {
        cout << line << endl; // Display each line from the file
    }
}

// Display game statistics at the end
void dspStats(int totGms, int plyrWns, int dealWns, int ties) {
    cout << "Game Statistics:" << endl;
    cout << "Total games played: " << abs(totGms) << endl;
    cout << "Player wins: " << abs(plyrWns) << endl;
    cout << "Dealer wins: " << abs(dealWns) << endl;
    cout << "Ties: " << abs(ties) << endl;
}

// Bubble sort to sort scores
void bblSort(vector<int> &scores) {
    int n = scores.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (scores[j] > scores[j + 1]) {
                swap(scores[j], scores[j + 1]); // Swap if current element is greater than next
            }
        }
    }
}

// Selection sort to sort scores
void slctSort(vector<int> &scores) {
    int n = scores.size();
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (scores[j] < scores[minIdx]) {
                minIdx = j;
            }
        }
        swap(scores[minIdx], scores[i]); // Swap the found minimum element with the first element
    }
}

// Display the sorted scores
void dspScores(const vector<int> &scores) {
    cout << "Sorted scores: ";
    for (int score : scores) {
        cout << abs(score) << " ";
    }
    cout << endl;
}

// Search for a specific score in the sorted list
bool srchScr(const vector<int> &scores, int score) {
    return binary_search(scores.begin(), scores.end(), abs(score));
}

// Overloaded function to search for a specific card in the player's hand
bool searchScore(const vector<string> &cardNames, const string &card) {
    return find(cardNames.begin(), cardNames.end(), card) != cardNames.end();
}

// Display all scores from the 2D array
void dsp2DArr(const int scores[][2], int rnds) {
    cout << "Scores (Player | Dealer):" << endl;
    for (int i = 0; i < rnds; ++i) {
        cout << "Round " << i + 1 << ": " << scores[i][0] << " | " << scores[i][1] << endl; // Display player and dealer scores for each round
    }
}
//  Displays winning in 1d array
void dsp1DArr(const int winnings[], int size) { cout << "Winnings for each game: "; for (int i = 0; i < size; ++i) { cout << winnings[i] << " "; } cout << endl; }
