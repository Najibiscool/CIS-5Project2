/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: taraf
 *
 * Created on July 25, 2024, 4:54 PM
 */

#include <iostream> 
#include <iomanip> 
#include <cmath> 
#include <cstdlib> 
#include <fstream> 
#include <string> 
#include <ctime> 
#include <vector>

using namespace std;

// Named constants
#define BLACKJACK 21 
#define DEALER_STAND 17 

// Function prototypes
void initializeGame(int &money);
int getBetAmount(int money);
void dealInitialCards(vector<int> &playerCards, vector<int> &dealerCards);
void displayPlayerCards(const vector<int> &cards);
int calculateTotal(const vector<int> &cards);
void playerTurn(vector<int> &playerCards, int &playerTotal);
void dealerTurn(vector<int> &dealerCards, int &dealerTotal);
void displayFinalResults(int playerTotal, int dealerTotal, int &money, int betAmount);

int main() {
    srand(static_cast<unsigned int>(time(0)));

    char again;
    int money, betAmount;
    ofstream outFile("game_results.txt");
    bool playerWins = false;
    int gameCount = 0;

    cout << "Welcome to the Blackjack game!" << endl;
    initializeGame(money);

    do {
        betAmount = getBetAmount(money);

        vector<int> playerCards;
        vector<int> dealerCards;
        dealInitialCards(playerCards, dealerCards);

        int playerTotal = calculateTotal(playerCards);
        int dealerTotal = calculateTotal(dealerCards);

        playerTurn(playerCards, playerTotal);
        if (playerTotal <= BLACKJACK) {
            dealerTurn(dealerCards, dealerTotal);
        }

        displayFinalResults(playerTotal, dealerTotal, money, betAmount);

        cout << "Player's total money: $" << money << endl;
        if (money < 10) {
            cout << "You don't have enough money to continue playing. Game over!" << endl;
            break;
        }

        cout << "Do you want to keep playing? (y/n): ";
        cin >> again;
        gameCount++;

    } while (again == 'y' && money >= 10);

    cout << "Total games played: " << gameCount << endl;
    outFile.close();
    return 0;
}

void initializeGame(int &money) {
    do {
        cout << "How much money do you want to have at the start of the game? (min 1, max 200): ";
        cin >> money;
        if (money > 200) {
            cout << "Overflow error: Starting money cannot be greater than 200. Starting Price is $200" << endl;
            money = 200;
        }
    } while (money < 1);
}

int getBetAmount(int money) {
    int betAmount;
    do {
        cout << "How much do you want to bet this round? (min 10, max 200): ";
        cin >> betAmount;
    } while (betAmount < 10 || betAmount > 200);
    return betAmount;
}

void dealInitialCards(vector<int> &playerCards, vector<int> &dealerCards) {
    for (int i = 0; i < 2; i++) {
        playerCards.push_back(rand() % 13 + 1);
        dealerCards.push_back(rand() % 13 + 1);
    }
}

void displayPlayerCards(const vector<int> &cards) {
    cout << "Player cards: ";
    for (int card : cards) {
        cout << card << " ";
    }
    cout << endl;
}

int calculateTotal(const vector<int> &cards) {
    int total = 0;
    int aces = 0;
    for (int card : cards) {
        if (card == 1) {
            aces++;
            total += 11;
        } else if (card > 10) {
            total += 10;
        } else {
            total += card;
        }
    }
    while (total > BLACKJACK && aces > 0) {
        total -= 10;
        aces--;
    }
    return total;
}

void playerTurn(vector<int> &playerCards, int &playerTotal) {
    char choice;
    do {
        displayPlayerCards(playerCards);
        cout << "Player total: " << playerTotal << ". Do you want to hit (h) or stand (s)? ";
        cin >> choice;
        if (choice == 'h') {
            playerCards.push_back(rand() % 13 + 1);
            playerTotal = calculateTotal(playerCards);
            if (playerTotal > BLACKJACK) {
                cout << "Player busts with " << playerTotal << "!" << endl;
                break;
            }
        }
    } while (choice == 'h');
}

void dealerTurn(vector<int> &dealerCards, int &dealerTotal) {
    while (dealerTotal < DEALER_STAND) {
        dealerCards.push_back(rand() % 13 + 1);
        dealerTotal = calculateTotal(dealerCards);
    }
    cout << "Dealer's total is " << dealerTotal << endl;
}

void displayFinalResults(int playerTotal, int dealerTotal, int &money, int betAmount) {
    cout << "Player final total: " << playerTotal << endl;
    cout << "Dealer final total: " << dealerTotal << endl;

    if (playerTotal > BLACKJACK) {
        cout << "Dealer wins!" << endl;
        money -= betAmount;
    } else if (dealerTotal > BLACKJACK || playerTotal > dealerTotal) {
        cout << "Player wins!" << endl;
        money += betAmount;
    } else if (playerTotal < dealerTotal) {
        cout << "Dealer wins!" << endl;
        money -= betAmount;
    } else {
        cout << "It's a tie!" << endl;
    }
}


