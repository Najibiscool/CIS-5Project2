/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/*
 * File:   main.cpp
 * Author: taraf
 *
 * Created on July 27, 2024, 12:38 PM
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime>
#include <vector>
#include <algorithm>

using namespace std;

// Function prototypes
void initializeGame(int &money);
int getBetAmount(int money, int minBet = 10, int maxBet = 200); // Defaulted arguments for minimum and maximum bet amounts
void dealInitialCards(vector<int> &playerCards, vector<int> &dealerCards, vector<string> &playerCardNames, vector<string> &dealerCardNames);
string cardToString(int card, int suit);
void displayPlayerCards(const vector<string> &cards);
int calculateTotal(const vector<int> &cards);
void playerTurn(vector<int> &playerCards, vector<string> &playerCardNames, int &playerTotal);
void dealerTurn(vector<int> &dealerCards, vector<string> &dealerCardNames, int &dealerTotal, int dealerStand);
void displayFinalResults(int playerTotal, int dealerTotal, int &money, int betAmount);
void recordGameResults(ofstream &outFile, int gameCount, int playerTotal, int dealerTotal, int money);
void formatOutput();
void readFromFile(ifstream &inFile);
void displayGameStatistics(int totalGames, int playerWins, int dealerWins, int ties);
void bubbleSort(vector<int> &scores);
void selectionSort(vector<int> &scores);
void displayScores(const vector<int> &scores);
bool searchScore(const vector<int> &scores, int score);
bool searchScore(const vector<string> &cardNames, const string &card); // Overloaded function for searching cards
void displayTwoDArray(const int scores[][2], int rounds); // Function prototype for displaying 2D array

int main() {
    // Seed the random number generator
    srand(static_cast<unsigned int>(time(0)));

    // Declare local variables
    char again;
    int money, betAmount;
    ofstream outFile("game_results.txt");
    ifstream inFile("game_scores.txt");
    int gameCount = 0;
    int playerWinCount = 0;
    int dealerWinCount = 0;
    int tieCount = 0;
    const int blackjack = 21;
    const int dealerStand = 17;
    vector<int> playerScores;
    const int maxRounds = 10; // Assume a maximum of 10 rounds
    int scores[maxRounds][2] = {}; // 2D array to store player and dealer scores

    // Welcome message
    cout << "Welcome to the Blackjack game!" << endl;

    // Initialize the game with the starting money
    initializeGame(money);

    // Main game loop
    do {
        // Get the bet amount for the current round
        betAmount = getBetAmount(money);

        // Vectors to store the cards and card names of the player and dealer
        vector<int> playerCards;
        vector<int> dealerCards;
        vector<string> playerCardNames;
        vector<string> dealerCardNames;

        // Deal the initial cards to the player and dealer
        dealInitialCards(playerCards, dealerCards, playerCardNames, dealerCardNames);

        // Calculate the initial totals of the player and dealer
        int playerTotal = calculateTotal(playerCards);
        int dealerTotal = calculateTotal(dealerCards);

        // Player's turn
        playerTurn(playerCards, playerCardNames, playerTotal);

        // If the player does not bust, the dealer takes their turn
        if (playerTotal <= blackjack) {
            dealerTurn(dealerCards, dealerCardNames, dealerTotal, dealerStand);
        }

        // Display the final results and update the player's money
        displayFinalResults(playerTotal, dealerTotal, money, betAmount);

        // Record the game results in a file
        recordGameResults(outFile, gameCount, playerTotal, dealerTotal, money);

        // Update win counts
        if (playerTotal > blackjack || (dealerTotal <= blackjack && dealerTotal > playerTotal)) {
            dealerWinCount++;
        } else if (dealerTotal > blackjack || playerTotal > dealerTotal) {
            playerWinCount++;
        } else {
            tieCount++;
        }

        // Add player score to the list
        playerScores.push_back(playerTotal);

        // Store the scores in the 2D array
        if (gameCount < maxRounds) {
            scores[gameCount][0] = playerTotal;
            scores[gameCount][1] = dealerTotal;
        }

        // Display the player's total money
        cout << "Player's total money: $" << abs(money) << endl;

        // Check if the player has enough money to continue playing
        if (money < 10) {
            cout << "You don't have enough money to continue playing. Game over!" << endl;
            exit(0); // Use exit function to end the game if the player doesn't have enough money
        }

        // Ask the player if they want to keep playing
        cout << "Do you want to keep playing? (y/n): ";
        cin >> again;

        // Increment the number of games played
        gameCount++;

    } while (again == 'y' && money >= 10 && gameCount < maxRounds);

    // Display the total number of games played
    cout << "Total games played: " << abs(gameCount) << endl;

    // Display all scores using the 2D array
    displayTwoDArray(scores, gameCount);

    // Close the output file
    outFile.close();

    // Read and display player scores from a file
    readFromFile(inFile);

    // Display game statistics
    displayGameStatistics(gameCount, playerWinCount, dealerWinCount, tieCount);

    // Sort and display player scores using selection sort
    selectionSort(playerScores);
    displayScores(playerScores);

    // Search for a specific score in the sorted list
    int searchFor = 21;
    if (searchScore(playerScores, searchFor)) {
        cout << "Score " << abs(searchFor) << " found in the list." << endl;
    } else {
        cout << "Score " << abs(searchFor) << " not found in the list." << endl;
    }

    return 0;
}

// Initialize the game with the starting money
void initializeGame(int &money) {
    static int initialCalls = 0; // Static variable to count the number of times the function is called
    initialCalls++;
    cout << "Initializing game for the " << abs(initialCalls) << " time(s)." << endl;

    do {
        cout << "How much money do you want to have at the start of the game? (min 1, max 200): ";
        cin >> money;
        if (money > 200) {
            cout << "Overflow error: Starting money cannot be greater than 200. Starting Price is $200" << endl;
            money = 200;
        }
    } while (money < 1);
}

// Get the bet amount for the current round with a default minimum bet amount
int getBetAmount(int money, int minBet, int maxBet) { // Defaulted arguments for minimum and maximum bet amounts
    int betAmount;
    do {
        cout << "How much do you want to bet this round? (min " << abs(minBet) << ", max " << abs(maxBet) << "): ";
        cin >> betAmount;
    } while (betAmount < minBet || betAmount > maxBet);
    return betAmount;
}

// Deal the initial cards to the player and dealer
void dealInitialCards(vector<int> &playerCards, vector<int> &dealerCards, vector<string> &playerCardNames, vector<string> &dealerCardNames) {
    for (int i = 0; i < 2; i++) {
        int card = rand() % 13 + 1;
        int suit = rand() % 4;
        playerCards.push_back(card);
        playerCardNames.push_back(cardToString(card, suit));
        
        card = rand() % 13 + 1;
        suit = rand() % 4;
        dealerCards.push_back(card);
        dealerCardNames.push_back(cardToString(card, suit));
    }
}

// Convert a card number and suit to a string representation
string cardToString(int card, int suit) {
    string cardStr;
    switch (card) {
        case 1: cardStr = "Ace"; break;
        case 11: cardStr = "Jack"; break;
        case 12: cardStr = "Queen"; break;
        case 13: cardStr = "King"; break;
        default: cardStr = to_string(card);
    }
    cardStr += " of ";
    switch (suit) {
        case 0: cardStr += "Clubs"; break;
        case 1: cardStr += "Diamonds"; break;
        case 2: cardStr += "Hearts"; break;
        case 3: cardStr += "Spades"; break;
    }
    return cardStr;
}

// Display the player's cards
void displayPlayerCards(const vector<string> &cards) {
    cout << "Player cards: ";
    for (const string &card : cards) {
        cout << card << " ";
    }
    cout << endl;
}

// Calculate the total value of the cards
int calculateTotal(const vector<int> &cards) {
    int total = 0;
    int aces = 0;
    for (int card : cards) {
        if (card == 1) {
            aces++;
            total += 11;
        } else if (card > 10) {
            total += 10;
        } else {
            total += card;
        }
    }
    while (total > 21 && aces > 0) {
        total -= 10;
        aces--;
    }
    return total;
}

// Player's turn to hit or stand
void playerTurn(vector<int> &playerCards, vector<string> &playerCardNames, int &playerTotal) {
    char choice;
    do {
        displayPlayerCards(playerCardNames);
        cout << "Player total: " << abs(playerTotal) << ". Do you want to hit (h) or stand (s)? ";
        cin >> choice;
        if (choice == 'h') {
            int card = rand() % 13 + 1;
            int suit = rand() % 4;
            playerCards.push_back(card);
            playerCardNames.push_back(cardToString(card, suit));
            playerTotal = calculateTotal(playerCards);
            if (playerTotal > 21) {
                cout << "Player busts with " << abs(playerTotal) << "!" << endl;
            }
        }
    } while (choice == 'h' && playerTotal <= 21);
}

// Dealer's turn to hit until they reach the stand limit
void dealerTurn(vector<int> &dealerCards, vector<string> &dealerCardNames, int &dealerTotal, int dealerStand) {
    while (dealerTotal < dealerStand) {
        int card = rand() % 13 + 1;
        int suit = rand() % 4;
        dealerCards.push_back(card);
        dealerCardNames.push_back(cardToString(card, suit));
        dealerTotal = calculateTotal(dealerCards);
    }
    cout << "Dealer's total is " << abs(dealerTotal) << endl;
}

// Display the final results of the game
void displayFinalResults(int playerTotal, int dealerTotal, int &money, int betAmount) {
    cout << "Player final total: " << abs(playerTotal) << endl;
    cout << "Dealer final total: " << abs(dealerTotal) << endl;

    if (playerTotal > 21) {
        cout << "Dealer wins!" << endl;
        money -= betAmount;
    } else if (dealerTotal > 21 || playerTotal > dealerTotal) {
        cout << "Player wins!" << endl;
        money += betAmount;
    } else if (playerTotal < dealerTotal) {
        cout << "Dealer wins!" << endl;
        money -= betAmount;
    } else {
        cout << "It's a tie!" << endl;
    }
}

// Record the game results in a file
void recordGameResults(ofstream &outFile, int gameCount, int playerTotal, int dealerTotal, int money) {
    outFile << "Game " << gameCount + 1 << ": " << endl;
    outFile << "Player total: " << abs(playerTotal) << endl;
    outFile << "Dealer total: " << abs(dealerTotal) << endl;
    outFile << "Player's total money: $" << abs(money) << endl;
    outFile << "------------------------" << endl;
}

// Format output to show an example of fixed and setprecision
void formatOutput() {
    double num = 1234.56789;
    cout << "Formatted number: " << fixed << setprecision(2) << num << endl;
}

// Read and display player scores from a file
void readFromFile(ifstream &inFile) {
    if (!inFile) {
        cout << "Error opening file!" << endl;
        return;
    }

    string line;
    while (getline(inFile, line)) {
        cout << line << endl;
    }
}

// Display game statistics at the end
void displayGameStatistics(int totalGames, int playerWins, int dealerWins, int ties) {
    cout << "Game Statistics:" << endl;
    cout << "Total games played: " << abs(totalGames) << endl;
    cout << "Player wins: " << abs(playerWins) << endl;
    cout << "Dealer wins: " << abs(dealerWins) << endl;
    cout << "Ties: " << abs(ties) << endl;
}

// Bubble sort to sort scores
void bubbleSort(vector<int> &scores) {
    int n = scores.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (scores[j] > scores[j + 1]) {
                swap(scores[j], scores[j + 1]);
            }
        }
    }
}

// Selection sort to sort scores
void selectionSort(vector<int> &scores) {
    int n = scores.size();
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (scores[j] < scores[minIndex]) {
                minIndex = j;
            }
        }
        swap(scores[minIndex], scores[i]);
    }
}

// Display the sorted scores
void displayScores(const vector<int> &scores) {
    cout << "Sorted scores: ";
    for (int score : scores) {
        cout << abs(score) << " ";
    }
    cout << endl;
}

// Search for a specific score in the sorted list
bool searchScore(const vector<int> &scores, int score) {
    return binary_search(scores.begin(), scores.end(), abs(score));
}

// Overloaded function to search for a specific card in the player's hand
bool searchScore(const vector<string> &cardNames, const string &card) {
    return find(cardNames.begin(), cardNames.end(), card) != cardNames.end();
}

// Display all scores from the 2D array
void displayTwoDArray(const int scores[][2], int rounds) {
    cout << "Scores (Player | Dealer):" << endl;
    for (int i = 0; i < rounds; ++i) {
        cout << "Round " << i + 1 << ": " << scores[i][0] << " | " << scores[i][1] << endl;
    }
}


